# encoding: utf-8

class Table(object):
    def config_db(self,pkg):
        pass
        #tbl=pkg.table('donator', pkey='id', name_long='Donator', name_plural='Donators',caption_field='surname')
        #self.sysFields(tbl)
        #
        #tbl.column('card_id',size='22', group='_', name_long=''
        #            ).relation('', relation_name='', mode='foreignkey', onDelete='raise')